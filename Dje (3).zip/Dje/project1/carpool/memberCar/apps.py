from django.apps import AppConfig


class MembercarConfig(AppConfig):
    name = 'memberCar'
