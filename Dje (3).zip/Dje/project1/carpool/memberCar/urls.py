
from django.urls import path,include
from .views import M


urlpatterns = [
    #path('carpool/', include('car_backend.urls')),   
    path('carpool/detail/', M.as_view(), name='member'),
   
]