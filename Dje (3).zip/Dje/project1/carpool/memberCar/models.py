from django.db import models

# Create your models here.
class member_car(models.Model):  #member_id belongs to one member
    id = models.AutoField(primary_key=True)
    member_id =  models.CharField(max_length = 30)
    
    car_id = models.CharField(max_length = 30)
    car_color = models.CharField(max_length=30)
    class meta:  
        debug='False'
        db_table = "member_car"
