from django.shortcuts import render
from .models import member_car
from django.views.generic.base import TemplateView



class M(TemplateView):
	def member_car_detail(request):
		obj = member_car.objects.get(id=1)
		context = obj
		return render(request,'member/detail.html', context)


