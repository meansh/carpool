from django.db import models


class city(models.Model):
    id = models.AutoField(primary_key = True)
    city_name = models.CharField(max_length = 20)
    state = models.CharField(max_length = 20)
    country = models.CharField(max_length = 10)	

class enroute_city(models.Model):  #one to many
	id = models.AutoField(primary_key = True)
	ride_id = models.CharField(max_length = 10)
	city_id = models.CharField(max_length = 30)
