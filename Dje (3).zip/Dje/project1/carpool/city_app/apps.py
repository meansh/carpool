from django.apps import AppConfig


class CityAppConfig(AppConfig):
    name = 'city_app'
