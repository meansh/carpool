from django.db import models



class request_status(models.Model):
	id = models.AutoField(primary_key=True)
	description = models.CharField(max_length=30, default = 'in a progress')
    


class request(models.Model):#many to one
  
	id = models.AutoField(primary_key=True)
	request_id = models.ForeignKey("city_app.enroute_city", on_delete=models.CASCADE)
	ride_id = models.CharField(max_length = 10)
	enroute_city_id = models.CharField(max_length = 10)
	created_on = models.DateTimeField()
	request_status_id = models.ForeignKey("request_status", on_delete=models.CASCADE)


class ride(models.Model):#one to many
	id = models.AutoField(primary_key=True)
	created_on = models.DateTimeField()
	travel_start_time = models.DateTimeField()
	source_city_id = models.ForeignKey("request", on_delete=models.CASCADE)
	destination_city_id = models.CharField(max_length = 30)
	seats_offered = models.IntegerField()
    
