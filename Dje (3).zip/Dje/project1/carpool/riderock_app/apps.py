from django.apps import AppConfig


class RiderockAppConfig(AppConfig):
    name = 'riderock_app'
