from django.apps import AppConfig


class CarBackendConfig(AppConfig):
    name = 'car_backend'
