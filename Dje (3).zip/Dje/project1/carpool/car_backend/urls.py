from django.urls import path
from car_backend.views import Homepageview, DashBoard, TimeLine, Logout, Stylish, LoginView, Signup, Final, Final12

urlpatterns = [
    path('carpool/shak2/', Homepageview.as_view(), name='Home'), 
    path('carpool/Dashboard/', DashBoard.as_view(), name='Dashboard'),  
    path('carpool/Timeline/', TimeLine.as_view(), name = 'Timeline'),
    path('carpool/logout/', Logout.as_view(), name = 'logout'),
    path('carpool/Stylish/', Stylish.as_view(), name = 'style'),
    path('carpool/Signup/', Signup.as_view(), name = 'Signup'),
    path('carpool/FinalPage/', Final.as_view(), name = 'Final'),
    path('carpool/Final12/', Final12.as_view(), name = 'Final12'),
    
    
]
