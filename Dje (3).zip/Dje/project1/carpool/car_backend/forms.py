from django import forms

class NameForm(forms.Form):
   UserName = forms.CharField( max_length=100)
   Password = forms.CharField(max_length = 100)