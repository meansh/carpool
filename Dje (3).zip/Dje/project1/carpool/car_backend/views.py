from django.views.generic.base import TemplateView
#from car_backend.models import member_car
from django.shortcuts import render, redirect
#from django.http import Http404
#from django.utils import timezone
from .forms import NameForm
from django.contrib.auth import login, authenticate
from django.contrib.auth.models import User


def signup(request):
    if request.method == 'POST':
        form = NameForm(request.POST)
        if form.is_valid():
            form.save()
            username = form.cleaned_data.get('username')
            raw_password = form.cleaned_data.get('password1')
            User = authenticate(username=username, password=raw_password)
            login(request, user)
            return redirect('/carpool/carpool/Stylish')
    else:
        form = NameForm()
    return render(request, 'Signup.html', {'form': form})


class Logout(TemplateView):
    template_name = "logout.html"


class Final(TemplateView):
    template_name = "FinalPage.html"


class Final12(TemplateView):
    template_name = "Final12.html"


class Signup(TemplateView):
    template_name = "Signup.html"

class LoginView(TemplateView):
    template_name = "login.html"

class Stylish(TemplateView):
    template_name = "Stylish.html"
    

class TimeLine(TemplateView):
    template_name = "Timeline.html"


class DashBoard(TemplateView):
    template_name = "Dashboard.html"


class Homepageview(TemplateView):
    template_name = "shak2.html"
    
   


