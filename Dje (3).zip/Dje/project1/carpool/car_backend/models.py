from django.db import models


"""class car(models.Model):
    id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=30)
    make = models.CharField(max_length=30)
    model = models.CharField(max_length=30)
    class meta:  
        debug='False'
        db_table = "car"
    
"""
class member(models.Model):
    FirstName = models.CharField(max_length=30)
    LastName = models.CharField(max_length=30)
    email = models.CharField(max_length=20)
    contact_no = models.IntegerField(default = '10')
    Address = models.CharField(max_length=30)
    Age = models.IntegerField()
    password = models.CharField(max_length=30)

            
"""
class member_car(models.Model):  #member_id belongs to one member
    id = models.AutoField(primary_key=True)
    member_id =  models.CharField(max_length = 30)
    
    car_id = models.CharField(max_length = 30)
    car_color = models.CharField(max_length=30)
    class meta:  
        debug='False'
        db_table = "member_car"

#member can be sit only on one car


"""
                                    

    
      

                                         
                                         
                                         

                                         
             
                                        

                                        
                                         
                                         
                                         
                                         
                                         
                                         
                                         
                                         
                                         
                                         
                                           
                                         
                                         

                                         
    
                                         
                                         
                                         