from django.contrib import admin


from .models import  member

#admin.site.register(car)
admin.site.register(member)
#admin.site.register(member_car)


